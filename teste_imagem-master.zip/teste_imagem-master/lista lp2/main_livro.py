from livros import Livro
nome = 'HpCaliceDeFogo'
autor = 'JKRowling'
livro = Livro(nome,636,autor,30.00)
livro.setpreco()
livro.getpreco()