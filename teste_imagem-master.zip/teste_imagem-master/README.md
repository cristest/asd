# teste_imagem
se ler é gay
